package org.example.javacwfinalll;

import static org.junit.Assert.*;

public class UpdateHorseDialogTest {

}