package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class DeleteHorseDialogTest {

    @Test
    public void deleteHorse() {
    }
}