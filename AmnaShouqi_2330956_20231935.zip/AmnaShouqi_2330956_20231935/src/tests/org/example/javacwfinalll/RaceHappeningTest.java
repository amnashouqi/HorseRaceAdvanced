package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class RaceHappeningTest {

    @Test
    public void selectHorses() {
    }

    @Test
    public void SWH() {
    }

    @Test
    public void graph() {
    }
}