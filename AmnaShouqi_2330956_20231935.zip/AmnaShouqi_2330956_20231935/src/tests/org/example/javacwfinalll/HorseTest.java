package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class HorseTest {

    @Test
    public void getID() {
    }

    @Test
    public void getName() {
    }

    @Test
    public void getJockeyName() {
    }

    @Test
    public void getAge() {
    }

    @Test
    public void getBreed() {
    }

    @Test
    public void getRaceRecord() {
    }

    @Test
    public void getGroup() {
    }

    @Test
    public void getHorseImage() {
    }

    @Test
    public void setID() {
    }

    @Test
    public void setName() {
    }

    @Test
    public void setJockeyName() {
    }

    @Test
    public void setAge() {
    }

    @Test
    public void setBreed() {
    }

    @Test
    public void setRaceRecord() {
    }

    @Test
    public void setGroup() {
    }

    @Test
    public void setHorseImage() {
    }

    @Test
    public void IDProperty() {
    }

    @Test
    public void nameProperty() {
    }

    @Test
    public void jockeyNameProperty() {
    }

    @Test
    public void ageProperty() {
    }

    @Test
    public void breedProperty() {
    }

    @Test
    public void raceRecordProperty() {
    }

    @Test
    public void groupProperty() {
    }

    @Test
    public void horseImageProperty() {
    }

    @Test
    public void getRaceTime() {
    }

    @Test
    public void getHorses() {
    }

    @Test
    public void getHorseById() {
    }
}