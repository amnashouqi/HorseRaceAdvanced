package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class HorseImageTest {

    @Test
    public void saveImage() {
    }

    @Test
    public void deleteAllImages() {
    }

    @Test
    public void deleteImage() {
    }

    @Test
    public void addShutdownHook() {
    }

    @Test
    public void createImageView() {
    }
}