package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class AddHorseDialogTest {

    @Test
    public void writeToFile() {
    }

    @Test
    public void isNumeric() {
    }
}