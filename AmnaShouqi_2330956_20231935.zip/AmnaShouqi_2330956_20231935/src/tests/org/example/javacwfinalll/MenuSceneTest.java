package org.example.javacwfinalll;

import org.junit.Test;

import static org.junit.Assert.*;

public class MenuSceneTest {

    @Test
    public void getScene() {
    }

    @Test
    public void show() {
    }

    @Test
    public void clearFile() {
    }

    @Test
    public void readFromFile() {
    }
}