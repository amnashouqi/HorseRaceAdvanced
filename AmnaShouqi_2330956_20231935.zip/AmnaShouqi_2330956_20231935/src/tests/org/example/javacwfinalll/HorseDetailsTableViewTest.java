package org.example.javacwfinalll;

import static org.junit.Assert.*;

public class HorseDetailsTableViewTest {

    @org.junit.Test
    public void display() {
    }
}