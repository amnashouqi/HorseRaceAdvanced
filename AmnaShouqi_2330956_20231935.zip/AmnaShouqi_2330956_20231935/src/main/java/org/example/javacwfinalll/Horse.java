package org.example.javacwfinalll;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.List;

import static org.example.javacwfinalll.MenuScene.readFromFile;


public class Horse {
    public int raceTime;
    private int ID;
    private StringProperty name;
    private StringProperty jockeyName;
    private StringProperty age;
    private StringProperty breed;
    private StringProperty raceRecord;
    private StringProperty group;
    private StringProperty horseImage;

    public Horse(int ID, String name, String jockeyName, String age, String breed, String raceRecord, String group, String horseImage) {
        this.ID = ID;
        this.name = new SimpleStringProperty(name);
        this.jockeyName = new SimpleStringProperty(jockeyName);
        this.age = new SimpleStringProperty(age);
        this.breed = new SimpleStringProperty(breed);
        this.raceRecord = new SimpleStringProperty(raceRecord);
        this.group = new SimpleStringProperty(group);
        this.horseImage = new SimpleStringProperty(horseImage);
    }


    // Getters
    public int getID() {
        return ID;
    }

    public String getName() {
        return name.get();
    }

    public String getJockeyName() {
        return jockeyName.get();
    }

    public String getAge() {
        return age.get();
    }

    public String getBreed() {
        return breed.get();
    }

    public String getRaceRecord() {
        return raceRecord.get();
    }

    public String getGroup() {
        return group.get();
    }

    public String getHorseImage() {
        return horseImage.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty jockeyNameProperty() {
        return jockeyName;
    }

    public StringProperty ageProperty() {
        return age;
    }

    public StringProperty breedProperty() {
        return breed;
    }

    public StringProperty raceRecordProperty() {
        return raceRecord;
    }

    public StringProperty groupProperty() {
        return group;
    }

    public int getRaceTime() {
        return raceTime;
    }

    public static Horse getHorseById(int horseId) {
        List<Horse> horses = readFromFile();
        for (Horse horse : horses) {
            if (horse.getID() == horseId) {
                return horse;
            }
        }
        return null; // Return null if horse with given ID is not found
    }
}



