package org.example.javacwfinalll;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import static org.example.javacwfinalll.HorseImage.deleteAllImages;
public class MenuScene {
public static String FILE_NAME = "dataStoring.txt"; // Only file name, not the full path
public static void clearFile() {
    try {
        // Clear the file by writing an empty string
        FileWriter fw = new FileWriter(FILE_NAME);
        fw.write("");
        fw.close();
        deleteAllImages();
        System.out.println("File has been cleared.");
    } catch (IOException e) {
        System.err.println("An error occurred while clearing the file: " + e.getMessage());
    }
}
    public static List<Horse> readFromFile() {
        List<Horse> horses = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Parse each line to create a Horse object
                String[] parts = line.split(","); // Assuming the fields are separated by commas
                if (parts.length == 8) { // Assuming there are 8 fields in each line
                    int ID = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String jockeyName = parts[2];
                    String age = parts[3];
                    String breed = parts[4];
                    String raceRecord = parts[5];
                    String group = parts[6];
                    String horseImage = parts[7];
                    Horse horse = new Horse(ID, name, jockeyName, age, breed, raceRecord, group, horseImage);
                    horses.add(horse);
                } else {
                    System.err.println("Invalid line format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("An error occurred while reading from the file: " + e.getMessage());
        }
        return horses;
    }
}
