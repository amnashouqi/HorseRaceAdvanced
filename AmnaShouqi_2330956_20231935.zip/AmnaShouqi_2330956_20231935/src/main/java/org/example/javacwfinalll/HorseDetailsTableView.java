package org.example.javacwfinalll;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import java.io.File;
import java.util.Comparator;
import java.util.List;

public class HorseDetailsTableView {

    public static void display(List<Horse> horses) {
        // Sort horses by ID in ascending order
        horses = MenuScene.readFromFile();
        horses.sort(Comparator.comparingInt(Horse::getID));

        TableView<Horse> tableView = new TableView<>();

        TableColumn<Horse, String> idColumn = new TableColumn<>("Horse ID");
        idColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().getID())));

        TableColumn<Horse, String> nameColumn = new TableColumn<>("Horse Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

// TableColumn for Jockey Name
        TableColumn<Horse, String> jockeyNameColumn = new TableColumn<>("Jockey Name");
        jockeyNameColumn.setCellValueFactory(cellData -> cellData.getValue().jockeyNameProperty());

// TableColumn for Age
        TableColumn<Horse, String> ageColumn = new TableColumn<>("Age");
        ageColumn.setCellValueFactory(cellData -> cellData.getValue().ageProperty());

// TableColumn for Breed
        TableColumn<Horse, String> breedColumn = new TableColumn<>("Breed");
        breedColumn.setCellValueFactory(cellData -> cellData.getValue().breedProperty());

// TableColumn for Race Record
        TableColumn<Horse, String> raceRecordColumn = new TableColumn<>("Race Record");
        raceRecordColumn.setCellValueFactory(cellData -> cellData.getValue().raceRecordProperty());

// TableColumn for Group
        TableColumn<Horse, String> groupColumn = new TableColumn<>("Group");
        groupColumn.setCellValueFactory(cellData -> cellData.getValue().groupProperty());


        TableColumn<Horse, Image> imageColumn = new TableColumn<>("Image");
        imageColumn.setCellValueFactory(cellData -> {
            String imagePath = cellData.getValue().getHorseImage();
            Image image = ImageLoader.loadImage(imagePath);
            return new SimpleObjectProperty<>(image);
        });

        imageColumn.setCellFactory(col -> {
            TableCell<Horse, Image> cell = new TableCell<>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(Image item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        imageView.setImage(item);
                        imageView.setFitWidth(50);
                        imageView.setPreserveRatio(true);
                        setGraphic(imageView);
                    }
                }
            };
            return cell;
        });


        idColumn.setPrefWidth(80);
        nameColumn.setPrefWidth(150);


// Set font style for column headers
        Font columnHeaderFont = Font.font("Arial", FontWeight.BOLD, 12);
        String columnHeaderStyle = "-fx-font: " + columnHeaderFont.getSize() + "px \"" + columnHeaderFont.getFamily() + "\";";

        idColumn.setStyle(columnHeaderStyle);
        nameColumn.setStyle(columnHeaderStyle);
        jockeyNameColumn.setStyle(columnHeaderStyle);
        ageColumn.setStyle(columnHeaderStyle);
        breedColumn.setStyle(columnHeaderStyle);
        raceRecordColumn.setStyle(columnHeaderStyle);
        groupColumn.setStyle(columnHeaderStyle);
        imageColumn.setStyle(columnHeaderStyle); // Assuming you want to style the header for the image column as well

// Set background color for column headers
        String columnHeaderBackground = "-fx-background-color: #f0f0f0;";
        idColumn.setStyle(columnHeaderBackground);
        nameColumn.setStyle(columnHeaderBackground);
        jockeyNameColumn.setStyle(columnHeaderBackground);
        ageColumn.setStyle(columnHeaderBackground);
        breedColumn.setStyle(columnHeaderBackground);
        raceRecordColumn.setStyle(columnHeaderBackground);
        groupColumn.setStyle(columnHeaderBackground);
        imageColumn.setStyle(columnHeaderBackground);

// Set text color for column headers
        String columnHeaderTextColor = "-fx-text-fill: #333333;";
        idColumn.setStyle(columnHeaderTextColor);
        nameColumn.setStyle(columnHeaderTextColor);
        jockeyNameColumn.setStyle(columnHeaderTextColor);
        ageColumn.setStyle(columnHeaderTextColor);
        breedColumn.setStyle(columnHeaderTextColor);
        raceRecordColumn.setStyle(columnHeaderTextColor);
        groupColumn.setStyle(columnHeaderTextColor);
        imageColumn.setStyle(columnHeaderTextColor);

        tableView.getColumns().addAll(imageColumn, idColumn, nameColumn, jockeyNameColumn, ageColumn, breedColumn, raceRecordColumn, groupColumn);

        // Populate TableView with horse details
        tableView.getItems().addAll(horses);

        VBox layout = new VBox(tableView);

        // Set spacing and padding for layout
        layout.setSpacing(10);

        // Set background color for layout
        layout.setStyle("-fx-background-color: #ffffff;");

        Scene scene = new Scene(layout);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Registered Horses' Details");
        stage.show();
    }


    public static class ImageLoader {
        public static Image loadImage(String imageName) {
            try {
                String imagePath = imageName;
                File imageFile = new File(imagePath);
                if (imageFile.exists()) {
                    return new Image(imageFile.toURI().toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        private static String extractFileName(String absolutePath) {
            return new File(absolutePath).getName();
        }
    }}




