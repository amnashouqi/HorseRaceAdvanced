package org.example.javacwfinalll;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RandomApplication extends Application {
    private Stage primaryStage;
    private Scene registrationScene;

    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("JAMES' HORSE RACE - REGISTRATION");
        VBox registrationContent = createRegistrationContent();
        registrationScene = new Scene(registrationContent, 800, 600);
// Set the registration scene
        this.primaryStage.setScene(registrationScene);
        this.primaryStage.show();
    }
    private VBox createRegistrationContent() {
        VBox root = new VBox();
        root.setSpacing(10);
        root.setStyle("-fx-background-color: lightblue; -fx-padding: 20;");

        Label titleLabel = new Label("Welcome to James' Horse Race Registration");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Button startButton = new Button("Start Race");
        startButton.setOnAction(e -> startRace());

        root.getChildren().addAll(titleLabel, startButton);
        return root;
    }
    private void startRace() {
        // Logic to start the race
        // For now, let's just switch to a placeholder scene
        Scene placeholderScene = createPlaceholderScene();
        primaryStage.setScene(placeholderScene);
    }
    private Scene createPlaceholderScene() {
        VBox placeholderContent = new VBox();
        placeholderContent.setStyle("-fx-background-color: lightgreen; -fx-padding: 20;");
        Label placeholderLabel = new Label("Race in progress...");
        placeholderContent.getChildren().add(placeholderLabel);
        return new Scene(placeholderContent, 800, 600);
    }
    public static void main(String[] args) {
        launch(args);
    }
}