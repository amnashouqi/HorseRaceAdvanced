package org.example.javacwfinalll;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Collections;
import java.util.List;

import static org.example.javacwfinalll.AddHorseDialog.writeToFile;
import static org.example.javacwfinalll.MenuScene.clearFile;
import static org.example.javacwfinalll.MenuScene.readFromFile;

public class DeleteHorseDialog extends Dialog<Horse> {

    public DeleteHorseDialog(Stage primaryStage) {
        setTitle("Delete Horse Details");
        setHeaderText("Enter the Horse ID to delete:");

        // Set the button types
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Create field and label
        TextField horseIdField = new TextField();
        horseIdField.setPromptText("Horse ID");

        // Add field to dialog pane
        GridPane dialogContent = new GridPane();
        dialogContent.setHgap(10);
        dialogContent.setVgap(10);
        dialogContent.addRow(0, new Label("Horse ID:"), horseIdField);

        getDialogPane().setContent(dialogContent);

        // Request focus on the Horse ID field by default.
        getDialogPane().lookupButton(ButtonType.OK).setOnMouseClicked(event -> {
            if (!validateInput(horseIdField.getText(), primaryStage)) {
                // Add validation for mandatory field
                event.consume(); // Prevent dialog from closing
            }
        });

        // Convert the result to a Horse when the OK button is clicked.
        setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                String horseId = horseIdField.getText();
                Horse horse = getHorseById(horseId);
                if (horse != null) {
                    deleteHorse(horse);
                    return horse;
                }else{
                    showAlert("Horse ID doesn't exist.", primaryStage);
                }
            }
            return null;
        });

        // Show the dialog
        initOwner(primaryStage);
    }

    // Method to retrieve Horse object based on horseId
    private Horse getHorseById(String horseId) {
        // Get the list of registered horses from your data source
        List<Horse> horses = readFromFile();

        // Iterate over the list to find the horse with the matching ID
        for (Horse horse : horses) {
            if (String.valueOf(horse.getID()).equals(horseId)) {
                return horse; // Return the horse if found
            }
        }
        return null; // Return null if no horse with the given ID is found
    }
    public static void deleteHorse(Horse horseToDelete) {
        List<Horse> horses = readFromFile();
        if (horses.removeIf(horse -> horse.getID() == horseToDelete.getID())) {
            clearFile();
            writeToFile(horses); // Update the file after removing the horse
            System.out.println("Horse deleted successfully.");
        } else {
            System.out.println("Horse not found.");
        }
    }
    private boolean validateInput(String input, Stage primaryStage) {
        if (!isNumeric(input)) {
            showAlert("Please enter a numeric Horse ID.", primaryStage);
            return false;
        }

        Horse horse = getHorseById(input);
        if (horse == null) {
            showAlert("Horse ID doesn't exist.", primaryStage);
            return false;
        }

        return true;
    }
    private void showAlert(String message, Stage primaryStage) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(primaryStage);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}