package org.example.javacwfinalll;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.Collections;
import java.util.List;

import static org.example.javacwfinalll.AddHorseDialog.isNumeric;


public class UpdateHorseDialog extends Dialog<Horse> {

    private TextField horseIdField;
    private TextField horseNameField;
    private TextField jockeyNameField;
    private TextField ageField;
    private TextField breedField;
    private TextField raceRecordField;
    private TextField groupField;
    private TextField horseImageField;

    public UpdateHorseDialog(Stage primaryStage) {
        setTitle("Update Horse Details");
        setHeaderText("Enter the Horse ID and updated details");

        // Set the button types
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Create fields and labels
        horseIdField = new TextField();
        horseIdField.setPromptText("Horse ID");
        horseNameField = new TextField();
        horseNameField.setPromptText("Horse Name");
        jockeyNameField = new TextField();
        jockeyNameField.setPromptText("Jockey Name");
        ageField = new TextField();
        ageField.setPromptText("Age");
        breedField = new TextField();
        breedField.setPromptText("Breed");
        raceRecordField = new TextField();
        raceRecordField.setPromptText("Race Record");
        groupField = new TextField();
        groupField.setPromptText("Group");
        horseImageField = new TextField();
        horseImageField.setPromptText("Horse Image");

        // Add fields to dialog pane
        GridPane dialogContent = new GridPane();
        dialogContent.setHgap(10);
        dialogContent.setVgap(10);

        dialogContent.addRow(1, new Label("Horse Name:"), horseNameField);
        dialogContent.addRow(2, new Label("Jockey Name:"), jockeyNameField);
        dialogContent.addRow(3, new Label("Age:"), ageField);
        dialogContent.addRow(4, new Label("Breed:"), breedField);
        dialogContent.addRow(5, new Label("Race Record:"), raceRecordField);
        dialogContent.addRow(6, new Label("Group:"), groupField);
//      dialogContent.addRow(7, new Label("Horse Image:"), horseImageField);

        /// Create and configure the Load button
        Button loadButton = new Button("Load");
        loadButton.setOnAction(event -> {
            // Retrieve the old horse based on the provided ID
            int oldHorseId = Integer.parseInt(horseIdField.getText());
            Horse oldHorse = Horse.getHorseById(oldHorseId);

            // If the old horse exists, populate the text fields with its data
            if (oldHorse != null) {
                horseNameField.setText(oldHorse.getName());
                jockeyNameField.setText(oldHorse.getJockeyName());
                ageField.setText(oldHorse.getAge());
                breedField.setText(oldHorse.getBreed());
                raceRecordField.setText(oldHorse.getRaceRecord());
                groupField.setText(oldHorse.getGroup());
                horseImageField.setText(oldHorse.getHorseImage());
            } else {
                // If the old horse does not exist, display an error message
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("The old Horse ID does not exist.");
                alert.showAndWait();
            }
        });

        dialogContent.addRow(0, new Label("Old Horse ID:"), horseIdField, loadButton);


        getDialogPane().setContent(dialogContent);
        getDialogPane().setContent(dialogContent);

        // Convert the result to a Horse object when the OK button is clicked.
//        setResultConverter(dialogButton -> {
//            if (dialogButton == ButtonType.OK) {
//                try {
//                    // Your existing code for handling OK button click
//                } catch (NumberFormatException e) {
//                    e.printStackTrace();
//                    return null;
//                }
//            } else {
//                // Handle the case where the user clicked the cancel button
//                return null;
//            }


        Button browseButton = new Button("Browse");
        browseButton.setOnAction(event -> {
            // Create a file chooser dialog
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose Horse Image");

            // Set initial directory
            fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));

            // Filter file types
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                    new FileChooser.ExtensionFilter("All Files", "*.*")
            );

            // Show the file chooser dialog
            File selectedFile = fileChooser.showOpenDialog(primaryStage);

            // If a file is selected, set its path to the horse image field
            if (selectedFile != null) {
                horseImageField.setText(selectedFile.toURI().toString());
            }
        });

// Add the Browse button to the GridPane at the appropriate row
        dialogContent.addRow(7, new Label("Horse Image:"), horseImageField, browseButton);


        getDialogPane().setContent(dialogContent);

        // Convert the result to a Horse object when the OK button is clicked.
        setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                try {
                    String oldHorseIdText = horseIdField.getText();
                    String horseIdText = horseIdField.getText();

                    // Check if the Horse ID and Age are numerical
                    if (!isNumeric(oldHorseIdText) || !isNumeric(horseIdText)) {
                        // Show an error message and return null if they are not numerical
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("Horse ID must be numerical and an entered value.");
                        alert.showAndWait();
                        return null;
                    }

                    int oldHorseId = Integer.parseInt(oldHorseIdText);
                    Horse oldHorse = Horse.getHorseById(oldHorseId);

                    // Check if the old horse exists
                    if (oldHorse == null) {
                        // Show an error message if the old horse does not exist
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("The old Horse ID does not exist.");
                        alert.showAndWait();
                        return null;
                    }

                    // If the old horse exists, proceed with the update
                    Horse updatedHorse = new Horse(
                            Integer.parseInt(horseIdField.getText()),
                            horseNameField.getText(),
                            jockeyNameField.getText(),
                            ageField.getText(),
                            breedField.getText(),
                            raceRecordField.getText(),
                            groupField.getText(),
                            horseImageField.getText()
                            // Add more fields as needed
                    );

                    // Perform the update operation
                    DeleteHorseDialog.deleteHorse(oldHorse);
                    AddHorseDialog.writeToFile(List.of(updatedHorse));
                    return updatedHorse;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return null;
                }
            } else {
                // Handle the case where the user clicked the cancel button
                return null;
            }
        });

        // Show the dialog
        initOwner(primaryStage);
    }

}
