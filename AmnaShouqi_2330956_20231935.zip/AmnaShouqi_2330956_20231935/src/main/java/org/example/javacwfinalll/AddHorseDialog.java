package org.example.javacwfinalll;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collections;
import java.util.List;

import static org.example.javacwfinalll.MenuScene.FILE_NAME;

public class AddHorseDialog extends Dialog<Horse> {
    public Horse horse;
    // Declare horseImageField as a class variable
    private TextField horseImageField;


    public AddHorseDialog(Stage primaryStage,List<Horse> existingHorses) {
        setTitle("Add Horse Details");
        setHeaderText("Enter the details of the horse");

        // Set the button types
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Create fields and labels
        TextField horseIdField = new TextField();
        horseIdField.setPromptText("Horse ID");
        TextField horseNameField = new TextField();
        horseNameField.setPromptText("Horse Name");
        TextField jockeyNameField = new TextField();
        jockeyNameField.setPromptText("Jockey Name");
        TextField ageField = new TextField();
        ageField.setPromptText("Age");
        TextField breedField = new TextField();
        breedField.setPromptText("Breed");
        TextField raceRecordField = new TextField();
        raceRecordField.setPromptText("Race Record");
        TextField groupField = new TextField();
        groupField.setPromptText("Group");
        horseImageField = new TextField();
        horseImageField.setPromptText("Horse Image");

        // Add fields to dialog pane
        GridPane dialogContent = new GridPane();
        dialogContent.setHgap(10);
        dialogContent.setVgap(10);
        dialogContent.addRow(0, new Label("Horse ID:"), horseIdField);
        dialogContent.addRow(1, new Label("Horse Name:"), horseNameField);
        dialogContent.addRow(2, new Label("Jockey Name:"), jockeyNameField);
        dialogContent.addRow(3, new Label("Age:"), ageField);
        dialogContent.addRow(4, new Label("Breed:"), breedField);
        dialogContent.addRow(5, new Label("Race Record:"), raceRecordField);
        dialogContent.addRow(6, new Label("Group:"), groupField);
        dialogContent.addRow(7, new Label("Horse Image:"), horseImageField);

        Button browseButton = new Button("Browse");
        browseButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose Horse Image");
            File selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                horseImageField.setText(selectedFile.getAbsolutePath());
                saveImageFile(selectedFile); // Call saveImageFile method here
            }
        });

        dialogContent.addRow(8, new Label(""), browseButton);

        getDialogPane().setContent(dialogContent);

        // Request focus on the Horse ID field by default.
        horseIdField.requestFocus();

        // Convert the result to a Horse object when the OK button is clicked.
        setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                try {
                    String horseIdText = horseIdField.getText();

                    // Check if the Horse ID is numerical
                    if (!isNumeric(horseIdText)) {
                        // Show an error message and return null if the Horse ID is not numerical
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("Horse ID must be a numerical value.");
                        alert.showAndWait();
                        return null;
                    }

                    int horseId = Integer.parseInt(horseIdText);
                    // Check if the entered Horse ID already exists
                    for (Horse existingHorse : existingHorses) {
                        if (existingHorse.getID() == horseId) {
                            // Show an error message and return null if the Horse ID already exists
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setHeaderText(null);
                            alert.setContentText("Horse ID already exists. Please enter a unique ID.");
                            alert.showAndWait();
                            return null;
                        }
                    }

                    Horse horse = new Horse(
                            horseId,
                            horseNameField.getText(),
                            jockeyNameField.getText(),
                            ageField.getText(),
                            breedField.getText(),
                            raceRecordField.getText(),
                            groupField.getText(),
                            horseImageField.getText()
                    );

                    writeToFile(List.of(horse));
                    return horse;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    return null;
                }
            }
            return null;
        });

        // Show the dialog
        initOwner(primaryStage);
    }
    public static void writeToFile(List<Horse> horses) {
        // Clear the existing file content

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            // Write new data to the file
            for (Horse horse : horses) {
                String line = horse.getID() + "," + horse.getName() + "," + horse.getJockeyName() + "," +
                        horse.getAge() + "," + horse.getBreed() + "," + horse.getRaceRecord() + "," +
                        horse.getGroup() + "," + horse.getHorseImage();
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Data has been written to the file.");
        } catch (IOException e) {
            System.err.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }
    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    private void saveImageFile(File imageFile) {
        try {
            // Read the image file as bytes
            byte[] imageData = Files.readAllBytes(imageFile.toPath());

            // Save the image file to the source directory
            String imageName = imageFile.getName();
            HorseImage.saveImage(imageName, imageData);

            // Set the image path in the text field
            horseImageField.setText(imageName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
