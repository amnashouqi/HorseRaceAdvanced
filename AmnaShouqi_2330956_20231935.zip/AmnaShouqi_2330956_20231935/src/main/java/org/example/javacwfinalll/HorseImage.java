package org.example.javacwfinalll;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class HorseImage {
    private static final String IMAGE_DIRECTORY = "";
    public static void saveImage(String imageName, byte[] imageData) throws IOException {
        String imagePath = IMAGE_DIRECTORY + imageName;
        try (FileOutputStream fos = new FileOutputStream(imagePath)) {
            fos.write(imageData);
        }
    }
    public static void deleteAllImages() {
        File directory = new File(IMAGE_DIRECTORY);
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.isDirectory()) {
                    file.delete();
                }
            }
        }
    }
}
