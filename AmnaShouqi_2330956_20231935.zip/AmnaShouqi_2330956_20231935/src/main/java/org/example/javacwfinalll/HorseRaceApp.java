package org.example.javacwfinalll;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.application.Platform;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class HorseRaceApp extends Application {
    private List<Horse> selectedHorses;
    private List<Horse> winningHorses;

    public void start(Stage primaryStage) {
        // Create the registration page UI
        Label registrationLabel = new Label("Welcome to the Horse Race!");
        registrationLabel.setFont(Font.font("Arial", 24)); // Increased font size
        registrationLabel.setTextFill(Color.BLACK);

        Button startButton = new Button("Start");
        startButton.setStyle("-fx-font-size: 20px; -fx-background-color: #4D4D4D; -fx-text-fill: white;"); // Increased font size and changed background color
        startButton.setOnMouseEntered(e -> {
            startButton.setStyle("-fx-font-size: 20px; -fx-background-color: #808080; -fx-text-fill: white;"); // Hover effect
            startButton.setCursor(Cursor.HAND); // Change cursor to hand pointer
        });
        startButton.setOnMouseExited(e -> {
            startButton.setStyle("-fx-font-size: 20px; -fx-background-color: #4D4D4D; -fx-text-fill: white;"); // Restore original style on exit
            startButton.setCursor(Cursor.DEFAULT); // Restore default cursor
        });
        startButton.setOnAction(e -> {
            // Navigate to the menu page
            primaryStage.setScene(createMenuScene(primaryStage));
        });

        StackPane registrationPane = new StackPane();
        registrationPane.getChildren().addAll(registrationLabel, startButton);
        StackPane.setMargin(registrationLabel, new Insets(50));
        StackPane.setMargin(startButton, new Insets(200, 0, 0, 0));
        registrationPane.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        Scene registrationScene = new Scene(registrationPane, 800, 600);

        // Set the registration page as the initial scene
        primaryStage.setScene(registrationScene);
        primaryStage.setTitle("Horse Race Registration");
        primaryStage.show();

        MenuScene.clearFile();
    }
    private Scene createMenuScene(Stage primaryStage) {
        // Create the menu page UI
        Label menuLabel = new Label("MENU");
        menuLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #000000;"); // Increased font size, bold text, and set text color to black
        Button addHorseButton = new Button("Add Horse");
        Button deleteHorseButton = new Button("Delete Horse");
        Button updateHorseButton = new Button("Update Horse");
        Button displayHorsesButton = new Button("Display Horses");
        Button SFHHorseButton = new Button("Select Horses for race");
        Button SWHHorseButton = new Button("Select Winning Horses");
        Button VWHHorseButton = new Button("View winning Horses");
        Button ESCButton = new Button("Exit");

        addHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        deleteHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        updateHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        displayHorsesButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        SFHHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        SWHHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        VWHHorseButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
        ESCButton.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");

// Set minimum width and height for all buttons
        addHorseButton.setMinWidth(200);
        addHorseButton.setMinHeight(40);

        deleteHorseButton.setMinWidth(200);
        deleteHorseButton.setMinHeight(40);

        updateHorseButton.setMinWidth(200);
        updateHorseButton.setMinHeight(40);

        displayHorsesButton.setMinWidth(200);
        displayHorsesButton.setMinHeight(40);

        SFHHorseButton.setMinWidth(200);
        SFHHorseButton.setMinHeight(40);

        SWHHorseButton.setMinWidth(200);
        SWHHorseButton.setMinHeight(40);

        VWHHorseButton.setMinWidth(200);
        VWHHorseButton.setMinHeight(40);

        ESCButton.setMinWidth(200);
        ESCButton.setMinHeight(40);

        ESCButton.setOnAction(e -> {
            Platform.exit();
        });

        SFHHorseButton.setOnAction(e -> {
            List<Horse> horses = MenuScene.readFromFile();
            selectedHorses = RaceHappening.selectHorses(horses, primaryStage);
        });

// Finally, in the SWHHorseButton event handler, use the stored selected horses to select the winning horses
        SWHHorseButton.setOnAction(event -> {
            if (selectedHorses.size() == 4) {
                winningHorses = RaceHappening.SWH(selectedHorses, primaryStage);
//                HorseRaceApp.displayWinningHorses(winningHorses);
            } else {
                // Handle the case where selectedHorses is null
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setHeaderText(null);
                alert.setContentText("Please select horses for the race first with at least one horse for each group.");
                alert.showAndWait();
            }
        });

        VWHHorseButton.setOnAction(e -> {
            displayGraph(winningHorses);
        });

        displayHorsesButton.setOnAction(e -> {
            // Open the add horse dialog
            displayHorseDetails();
        });

        addHorseButton.setOnAction(e -> {if (confirmRaceStatus(primaryStage)) {
            // Open the add horse dialog
            AddHorseDialog dialog = new AddHorseDialog(primaryStage, MenuScene.readFromFile());
            dialog.showAndWait();
        }});

        updateHorseButton.setOnAction(e -> {
            if (confirmRaceStatus(primaryStage)) {
                // Open the update horse dialog
                UpdateHorseDialog updateHorseDialog = new UpdateHorseDialog(primaryStage);
                updateHorseDialog.showAndWait();
            }
        });

        deleteHorseButton.setOnAction(e -> {
            if (confirmRaceStatus(primaryStage)) {
                // Open the delete horse dialog
                DeleteHorseDialog deleteHorseDialog = new DeleteHorseDialog(primaryStage);
                deleteHorseDialog.showAndWait();
                Horse horseId = deleteHorseDialog.getResult();
                if (horseId != null) {
                    // Perform deletion logic based on the horse ID
                }
            }
        });

        // Layout the menu buttons
        VBox menuButtons = new VBox(20);
        menuButtons.getChildren().addAll(menuLabel, addHorseButton, deleteHorseButton, updateHorseButton, displayHorsesButton, SFHHorseButton, SWHHorseButton, VWHHorseButton, ESCButton);
        menuButtons.setPadding(new Insets(20));
        menuButtons.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));

        // Create the menu page UI
        VBox menuBox = new VBox(20); // VBox to hold menu components with vertical spacing of 20px
        menuBox.setAlignment(Pos.CENTER); // Align menu components to the center

        // Button descriptions
        Map<Button, String> buttonDescriptions = new HashMap<>();
        buttonDescriptions.put(addHorseButton, "Add a new horse to the race");
        buttonDescriptions.put(deleteHorseButton, "Delete an existing horse from the race");
        buttonDescriptions.put(updateHorseButton, "Update information of an existing horse");
        buttonDescriptions.put(displayHorsesButton, "Display all horses participating in the race");
        buttonDescriptions.put(SFHHorseButton, "Select horses for the race");
        buttonDescriptions.put(SWHHorseButton, "Select the winning horses");
        buttonDescriptions.put(VWHHorseButton, "View the winning horses");
        buttonDescriptions.put(ESCButton, "Exit the application");

// Style and set descriptions for buttons
        for (Button button : buttonDescriptions.keySet()) {
            button.setStyle("-fx-font-size: 18px; -fx-cursor: default; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
            Tooltip tooltip = new Tooltip(buttonDescriptions.get(button));
            Tooltip.install(button, tooltip);

            button.setOnMouseEntered(e -> button.setStyle("-fx-cursor: hand; -fx-font-size: 18px; -fx-background-color: #808080;")); // Change background color on hover
            button.setOnMouseExited(e -> {
                button.setStyle("-fx-font-size: 18px; -fx-background-color: #4D4D4D; -fx-text-fill: white;");
                button.setCursor(Cursor.DEFAULT);
            });
        }
        menuBox.getChildren().addAll(menuLabel, addHorseButton, deleteHorseButton, updateHorseButton,
                displayHorsesButton, SFHHorseButton, SWHHorseButton, VWHHorseButton, ESCButton);

// Set margins for the menu label and buttons
        VBox.setMargin(menuLabel, new Insets(20, 0, 0, 0));
        VBox.setMargin(ESCButton, new Insets(0, 0, 20, 0));
        menuBox.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Scene menuScene = new Scene(menuBox, 700, 700);
        primaryStage.setTitle("Horse Race Menu");
        return menuScene;
    }
    private void displayHorseDetails() {
        List<Horse> horses = MenuScene.readFromFile();
        HorseDetailsTableView.display(horses);
    }

    public static void displayWinningHorses(List<Horse> winningHorses) {
        // Create a dialog box
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Winning Horses");
        alert.setHeaderText("The winning horses:");

        // Create a VBox to hold the details of winning horses
        VBox vbox = new VBox();

        // Populate the VBox with the details of winning horses
        for (Horse horse : winningHorses) {
            Label horseLabel = new Label("Horse ID: " + horse.getID() + ", Race Time: " + horse.raceTime + " seconds");
            vbox.getChildren().add(horseLabel);
        }
        // Set the content of the dialog box to the VBox
        alert.getDialogPane().setContent(vbox);

        // Show the dialog box
        alert.showAndWait();
    }
    private void displayGraph(List<Horse> winningHorses) {
        // Create a new stage for displaying the graph
        Stage graphStage = new Stage();
        graphStage.setTitle("Winning Horses Graph");

        // Create the graph
        RaceHappening.graph(winningHorses, graphStage);
        // Show the graph in a separate dialog
        graphStage.show();
    }
    // Method to confirm if the race has begun
    private boolean confirmRaceStatus(Stage primaryStage) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Race Status");
        alert.setHeaderText(null);
        alert.setContentText("Has the race begun?");

        ButtonType yesButton = new ButtonType("No", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("Yes", ButtonBar.ButtonData.NO);
        alert.getButtonTypes().setAll(yesButton, noButton);

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == yesButton) {
            return true; // Race has begun
        } else {
            // Race hasn't begun, show a message
            Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
            infoAlert.setTitle("Race Information");
            infoAlert.setHeaderText(null);
            infoAlert.setContentText("SORRY! You can't make changes now :(");
            infoAlert.showAndWait();
            // No need to exit the application here
            return false;
        }
    }
}

