package org.example.javacwfinalll;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.*;

import static org.example.javacwfinalll.HorseRaceApp.displayWinningHorses;

public class RaceHappening {

    // Method to simulate the race and select a random horse from each group
    public static List<Horse> selectHorses(List<Horse> horses, Stage primaryStage) {
        // Create separate lists to hold horses from each group
        List<Horse> groupA = new ArrayList<>();
        List<Horse> groupB = new ArrayList<>();
        List<Horse> groupC = new ArrayList<>();
        List<Horse> groupD = new ArrayList<>();

        // Separate horses into their respective groups
        for (Horse horse : horses) {
            String group = horse.getGroup();
            switch (group) {
                case "A":
                    groupA.add(horse);
                    break;
                case "B":
                    groupB.add(horse);
                    break;
                case "C":
                    groupC.add(horse);
                    break;
                case "D":
                    groupD.add(horse);
                    break;
            }
        }

        // Randomly select a horse from each group
        Horse topHorseGroupA = getRandomHorse(groupA);
        Horse topHorseGroupB = getRandomHorse(groupB);
        Horse topHorseGroupC = getRandomHorse(groupC);
        Horse topHorseGroupD = getRandomHorse(groupD);

                // Create a VBox to hold the horse details
        VBox horseDetails = new VBox();
        horseDetails.getChildren().addAll(
                new Label("Top horse from Group A: " + (topHorseGroupA != null ? topHorseGroupA.getID() : "No horse found")),
                new Label("Top horse from Group B: " + (topHorseGroupB != null ? topHorseGroupB.getID() : "No horse found")),
                new Label("Top horse from Group C: " + (topHorseGroupC != null ? topHorseGroupC.getID() : "No horse found")),
                new Label("Top horse from Group D: " + (topHorseGroupD != null ? topHorseGroupD.getID() : "No horse found"))
        );

        List<Horse> selectedHorses = new ArrayList<>();
        selectedHorses.add(topHorseGroupA);
        selectedHorses.add(topHorseGroupB);
        selectedHorses.add(topHorseGroupC);
        selectedHorses.add(topHorseGroupD);


        // Create an alert dialog to display the horse details
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(primaryStage);
        alert.setTitle("Selected Horses for Race");
        alert.setHeaderText(null);
        alert.getDialogPane().setContent(horseDetails);
        alert.showAndWait();

        return selectedHorses;
    }

    // Method to randomly select a horse from a given list of horses
    private static Horse getRandomHorse(List<Horse> horses) {
        if (horses.isEmpty()) {
            return null;
        }
        Random random = new Random();
        int index = random.nextInt(horses.size());
        return horses.get(index);
    }

    // Method to assign random times for each horse of each group and select the 1st, 2nd, and 3rd horses according to their race times
    public static List<Horse> SWH(List<Horse> horses, Stage primaryStage) {
        // Ensure there is at least one horse from each group before proceeding
        if (!hasOneHorseFromEachGroup(horses)) {
            displayErrorMessage(primaryStage, "There should be one horse from each group to proceed.");
            return horses; // Return an empty list if requirements are not met
        }
        int numGroups = 4;
        // Assign random times for each horse of each group
        assignRandomTimes(horses);

        // Sort horses based on their race time using Selection Sort
        selectionSort(horses);

        // Select the 1st, 2nd, and 3rd horses from the sorted list
        List<Horse> topThreeHorses = horses.subList(0, Math.min(3, horses.size()));
        displayWinningHorses(topThreeHorses);
        // Return the top three horses
        return topThreeHorses;
    }

    // Selection Sort algorithm to sort horses based on their race time
    private static void selectionSort(List<Horse> horses) {
        int n = horses.size();
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (horses.get(j).getRaceTime() < horses.get(minIndex).getRaceTime()) {
                    minIndex = j;
                }
            }
            // Swap horses at minIndex and i
            Horse temp = horses.get(minIndex);
            horses.set(minIndex, horses.get(i));
            horses.set(i, temp);
        }
    }

    // Method to ensure there is at least one horse from each group
    private static boolean hasOneHorseFromEachGroup(List<Horse> horses) {
        boolean hasGroupA = false, hasGroupB = false, hasGroupC = false, hasGroupD = false;
        for (Horse horse : horses) {
            switch (horse.getGroup()) {
                case "A":
                    hasGroupA = true;
                    break;
                case "B":
                    hasGroupB = true;
                    break;
                case "C":
                    hasGroupC = true;
                    break;
                case "D":
                    hasGroupD = true;
                    break;
            }
        }
        return hasGroupA && hasGroupB && hasGroupC && hasGroupD;
    }

    private static void displayErrorMessage(Stage primaryStage, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(primaryStage);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static void assignRandomTimes(List<Horse> horses) {
        Random random = new Random();
        for (Horse horse : horses) {
            int time = random.nextInt(91); // Random time between 0 to 90 seconds
            horse.raceTime = time; // Directly access and set the race time attribute
        }
    }
    public static void graph(List<Horse> winningHorses, Stage primaryStage) {
        // Create a bar chart
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);

        // Set chart title
        barChart.setTitle("Winning Horses Race Time");

        // Set labels for x and y axis
        xAxis.setLabel("Horse ID");
        yAxis.setLabel("Race Time");

        // Create a series for the data
        XYChart.Series<String, Number> series = new XYChart.Series<>();

        // Add data to the series
        for (Horse horse : winningHorses) {
            // Convert horse ID to String
            String horseID = String.valueOf(horse.getID());
            series.getData().add(new XYChart.Data<>(horseID, horse.getRaceTime()));
        }

        // Add the series to the chart
        barChart.getData().add(series);

        // Set custom styles for the bars
        barChart.setBarGap(5); // Adjust spacing between bars
        barChart.setCategoryGap(100); // Adjust spacing between categories (bars in the same group)

        // Customize axis labels
        xAxis.setTickLabelRotation(45); // Rotate x-axis labels
        xAxis.setStyle("-fx-font-size: 12pt;"); // Adjust font size

        // Add data labels to the bars
        for (XYChart.Data<String, Number> data : series.getData()) {
            StackPane stackPane = (StackPane) data.getNode();
            Text text = new Text(data.getYValue() + "s");
            stackPane.getChildren().add(text);
        }

        // Create a scene and add the chart to it
        Scene scene = new Scene(barChart, 800, 600);

        // Set the scene to the stage and show the stage
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
