module org.example.javacwfinalll {
    requires javafx.controls;
    requires javafx.fxml;
//    requires java.desktop;

    opens org.example.javacwfinalll to javafx.fxml;
    exports org.example.javacwfinalll;

}
